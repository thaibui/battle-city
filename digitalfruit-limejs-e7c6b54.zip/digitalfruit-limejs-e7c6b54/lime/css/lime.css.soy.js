// This file was automatically generated from lime.css.soy.
// Please don't edit this file by hand.

goog.provide('lime.css');

goog.require('soy');
goog.require('soy.StringBuilder');


lime.css.css = function(opt_data, opt_sb) {
  var output = opt_sb || new soy.StringBuilder();
  output.append('.', goog.getCssName('lime-director'), ' {position:absolute; -webkit-transform-origin: 0 0; -moz-transform-origin: 0 0; -o-transform-origin: 0 0; image-rendering:  optimizeSpeed; overflow: hidden;}.', goog.getCssName('lime-director'), ' div, .', goog.getCssName('lime-director'), ' img, .', goog.getCssName('lime-director'), ' canvas {-webkit-transform-origin: 0 0; -moz-transform-origin: 0 0; -o-transform-origin: 0 0; position: absolute; -moz-user-select: none; -webkit-user-select: none; -webkit-user-drag: none;}.', goog.getCssName('lime-scene'), ' {position:absolute; width:100%; height:100%; left: 0px; top: 0px; overflow: hidden;}.', goog.getCssName('lime-fps'), ' {float: left; background: #333; color: #fff; position: absolute; top:0px; left: 0px; padding:2px 4px;}div.', goog.getCssName('lime-layer'), ' {position: absolute; left: 0px; top: 0px; width:0px; height:0px;}.', goog.getCssName('lime-cover'), ' {position: absolute; left: 0px; top: 0px;}.', goog.getCssName('lime-button'), ' {cursor: pointer;}');
  if (!opt_sb) return output.toString();
};
